import { useEffect, useState } from 'react'

interface EvidenceRef {
  source_file: string
  record_id: string
}

interface Alert {
  alert_id: string
  incident_id: string
  subject: {
    type: string
    id: string
  }
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  what: string
  why: string
  evidence_refs: EvidenceRef[]
  risk_score_ref: string
  impact: string
  recommended_action: string
  status: string
  first_seen: string
  last_seen: string
  dup_count: number
}

interface ChainStage {
  stage: string
  event_ref: string
  link_provenance: string
}

interface IncidentChain {
  incident_id: string
  stages: ChainStage[]
  links: string[]
  subject_ids: string[]
  confidence: number
}

interface RiskFactor {
  name: string
  weight: number
  value: number
  contribution: number
}

interface RiskScore {
  subject: { type: string; id: string }
  total: number
  factors: RiskFactor[]
  explanation: {
    top_factors: string[]
    counterfactual?: string
  }
}

interface GraphNode {
  id: string
  label: string
  type: string
  sensitivity: string
}

interface GraphEdge {
  from: string
  to: string
  type: string
  provenance: string
}

interface RankedPath {
  path_id: string
  subject: string
  target: string
  risk_level: string
  hops: { node: string; type: string }[]
  description: string
}

export default function App() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null)
  const [chains, setChains] = useState<IncidentChain[]>([])
  const [scores, setScores] = useState<RiskScore[]>([])
  const [graphData, setGraphData] = useState<{ nodes: GraphNode[]; edges: GraphEdge[]; ranked_paths: RankedPath[] } | null>(null)
  const [weights, setWeights] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [simResult, setSimResult] = useState<string | null>(null)
  const [stepUpPrompt, setStepUpPrompt] = useState<string | null>(null)
  const [maskIdentities, setMaskIdentities] = useState<boolean>(true)
  const [activeTab, setActiveTab] = useState<'details' | 'graph' | 'feedback'>('details')

  const formatIdentity = (id: string) => {
    if (!maskIdentities) return id
    if (id.includes('@')) {
      const parts = id.split('@')
      return `${parts[0].slice(0, 2)}***@${parts[1]}`
    }
    return `${id.slice(0, 3)}***`
  }

  const loadData = () => {
    setLoading(true)
    Promise.all([
      fetch('http://127.0.0.1:8000/api/alerts').then(r => r.json()),
      fetch('http://127.0.0.1:8000/api/chains').then(r => r.json()),
      fetch('http://127.0.0.1:8000/api/scores').then(r => r.json()),
      fetch('http://127.0.0.1:8000/api/graph').then(r => r.json()),
      fetch('http://127.0.0.1:8000/api/feedback/weights').then(r => r.json())
    ])
      .then(([alertData, chainData, scoreData, gData, wData]) => {
        const alts = alertData.alerts || []
        setAlerts(alts)
        if (alts.length > 0) setSelectedAlert(alts[0])
        setChains(chainData.chains || [])
        setScores(scoreData.scores || [])
        setGraphData(gData.graph || null)
        setWeights(wData.weights || {})
        setLoading(false)
      })
      .catch(err => {
        setError(err.message)
        setLoading(false)
      })
  }

  useEffect(() => {
    loadData()
  }, [])

  const handleApprove = () => {
    if (!selectedAlert) return
    fetch('http://127.0.0.1:8000/api/actions/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        incident_id: selectedAlert.incident_id,
        action: selectedAlert.recommended_action,
        target: selectedAlert.subject.id,
        approver: 'lead_analyst@corp.internal'
      })
    })
      .then(res => res.json())
      .then(data => {
        setSimResult(data.action?.result || 'SUCCESS_SIMULATED')
      })
      .catch(err => setError(err.message))
  }

  const handleStepUp = () => {
    if (!selectedAlert) return
    fetch('http://127.0.0.1:8000/api/actions/step-up', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        incident_id: selectedAlert.incident_id,
        target: selectedAlert.subject.id
      })
    })
      .then(res => res.json())
      .then(data => {
        setStepUpPrompt(data.prompt || 'MFA challenge dispatched')
      })
      .catch(err => setError(err.message))
  }

  const handleWeightFeedback = (factor: string, direction: 'INCREASE' | 'DECREASE') => {
    fetch('http://127.0.0.1:8000/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ factor, direction })
    })
      .then(res => res.json())
      .then(data => {
        if (data.all_weights) setWeights(data.all_weights)
      })
      .catch(err => setError(err.message))
  }

  const activeChain = chains.find(c => c.incident_id === selectedAlert?.incident_id)
  const activeScore = scores.find(s => s.subject.id === selectedAlert?.subject.id)

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Banner (Binding Requirement) */}
      <div className="bg-amber-950/60 border-b border-amber-600/50 px-4 py-1.5 text-center text-xs font-mono uppercase tracking-widest text-amber-300">
        Replay of supplied/synthetic data. Not live.
      </div>

      {/* Navigation Header */}
      <header className="border-b border-slate-800 px-6 py-4 flex items-center justify-between bg-slate-900/60 backdrop-blur sticky top-0 z-10">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-600/30">
            ZT
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-bold text-white tracking-tight">Zero Trust Identity Protection</h1>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                Track 2
              </span>
            </div>
            <p className="text-xs text-slate-400">AWS CloudTrail + Okta Session Threat Correlation Engine</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Navigation Tabs */}
          <div className="flex bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-xs font-medium">
            <button
              onClick={() => setActiveTab('details')}
              className={`px-3 py-1 rounded-md transition-colors ${activeTab === 'details' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              Incidents
            </button>
            <button
              onClick={() => setActiveTab('graph')}
              className={`px-3 py-1 rounded-md transition-colors ${activeTab === 'graph' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              Attack Graph
            </button>
            <button
              onClick={() => setActiveTab('feedback')}
              className={`px-3 py-1 rounded-md transition-colors ${activeTab === 'feedback' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              Model Tuning
            </button>
          </div>

          <button
            onClick={() => setMaskIdentities(!maskIdentities)}
            className="px-3 py-1 text-xs rounded-md border border-slate-700 hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer flex items-center space-x-1.5"
          >
            <span>{maskIdentities ? '🔒 Masked' : '👁️ Unmasked'}</span>
          </button>
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5"></span>
            FASTAPI 8000
          </span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6">
        {activeTab === 'details' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: Alert Queue (4 cols) */}
            <section className="lg:col-span-4 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">Incident Alert Queue</h2>
                <span className="text-xs font-mono text-slate-500">{alerts.length} Incidents</span>
              </div>

              {loading && (
                <div className="p-8 text-center border border-slate-800 rounded-xl bg-slate-900/30">
                  <div className="inline-block animate-spin w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full mb-2"></div>
                  <p className="text-xs text-slate-400">Loading incident stream...</p>
                </div>
              )}

              {error && (
                <div className="p-4 border border-rose-800/50 bg-rose-950/20 rounded-xl text-xs text-rose-300">
                  <p className="font-semibold mb-1">Service Notice</p>
                  <p>{error}</p>
                </div>
              )}

              <div className="space-y-2">
                {alerts.map(alt => {
                  const isSelected = selectedAlert?.alert_id === alt.alert_id
                  return (
                    <div
                      key={alt.alert_id}
                      onClick={() => setSelectedAlert(alt)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-slate-900 border-indigo-500/80 shadow-lg shadow-indigo-950/50'
                          : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-rose-950 text-rose-300 border border-rose-800">
                          {alt.severity}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">
                          Dups: {alt.dup_count}
                        </span>
                      </div>
                      <h3 className="text-sm font-semibold text-white leading-snug">{alt.what}</h3>
                      <div className="mt-2 text-xs font-mono text-slate-400 flex items-center justify-between">
                        <span>{formatIdentity(alt.subject.id)}</span>
                        <span className="text-amber-400 font-semibold">{alt.recommended_action}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            </section>

            {/* Right Column: Incident Details, Timeline, Breakdown, Action (8 cols) */}
            <section className="lg:col-span-8 space-y-6">
              {selectedAlert ? (
                <>
                  {/* Incident Header Card */}
                  <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-xs font-mono text-indigo-400 uppercase tracking-wider">
                          {selectedAlert.alert_id} • {selectedAlert.incident_id}
                        </span>
                        <h2 className="text-xl font-bold text-white mt-1">{selectedAlert.what}</h2>
                        <p className="text-xs text-slate-400 mt-1">{selectedAlert.why}</p>
                      </div>
                      <div className="text-right font-mono text-xs text-slate-300">
                        <div>First Seen: <span className="text-slate-400">{selectedAlert.first_seen}</span></div>
                        <div>Last Seen: <span className="text-slate-400">{selectedAlert.last_seen}</span></div>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs">
                      <span className="text-slate-400 font-semibold">Impact Assessment: </span>
                      <span className="text-slate-200">{selectedAlert.impact}</span>
                    </div>
                  </div>

                  {/* Risk Score Breakdown Panel (U2 & U3) */}
                  {activeScore && (
                    <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                            Additive Factor Risk Score (U2)
                          </h3>
                          <p className="text-xs text-slate-500">Transparent weighted model (0–100)</p>
                        </div>
                        <div className="text-2xl font-black font-mono text-rose-400">
                          {activeScore.total} <span className="text-xs text-slate-500">/ 100</span>
                        </div>
                      </div>

                      {/* Factor Contribution Bars */}
                      <div className="space-y-2">
                        {activeScore.factors.map(f => (
                          <div key={f.name} className="space-y-1">
                            <div className="flex items-center justify-between text-xs font-mono">
                              <span className="text-slate-300 capitalize">{f.name.replace('_', ' ')}</span>
                              <span className="text-indigo-400">+{f.contribution} pts ({f.weight * 100}% wt)</span>
                            </div>
                            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                              <div
                                className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                                style={{ width: `${Math.min(100, f.value)}%` }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Explanation & Top Contributing Factors (U3) */}
                      <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                        <div className="text-slate-400 font-semibold">Top Contributing Factors (U3):</div>
                        <div className="flex flex-wrap gap-2 pt-1">
                          {activeScore.explanation.top_factors.map(tf => (
                            <span key={tf} className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[11px] font-mono">
                              {tf}
                            </span>
                          ))}
                        </div>
                        {activeScore.explanation.counterfactual && (
                          <p className="text-slate-400 text-[11px] pt-1 italic">
                            Counterfactual: {activeScore.explanation.counterfactual}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Provenance-Labeled Attack Chain Timeline (B5 / M3) */}
                  <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                          Reconstructed Attack Chain Timeline (M3)
                        </h3>
                        <p className="text-xs text-slate-500">Cross-source correlated stages with provenance legend</p>
                      </div>
                      {activeChain && (
                        <span className="text-xs font-mono text-emerald-400 border border-emerald-800/80 bg-emerald-950 px-2.5 py-0.5 rounded-full">
                          Confidence: {activeChain.confidence * 100}%
                        </span>
                      )}
                    </div>

                    {/* Provenance Legend */}
                    <div className="flex items-center space-x-4 text-[11px] font-mono text-slate-400 border-b border-slate-800/60 pb-3">
                      <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5"></span> VALIDATED_OBSERVATION</span>
                      <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-indigo-400 mr-1.5"></span> LABEL_DERIVED</span>
                      <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-amber-400 mr-1.5"></span> ANALYTICAL_INFERENCE</span>
                    </div>

                    {/* Stage Steps */}
                    <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
                      {activeChain?.stages.map((st, idx) => {
                        const provColor =
                          st.link_provenance === 'VALIDATED_OBSERVATION'
                            ? 'border-emerald-500 bg-emerald-950 text-emerald-300'
                            : st.link_provenance === 'LABEL_DERIVED'
                            ? 'border-indigo-500 bg-indigo-950 text-indigo-300'
                            : 'border-amber-500 bg-amber-950 text-amber-300'

                        return (
                          <div key={idx} className="relative">
                            <span className={`absolute -left-[27px] top-1 w-3 h-3 rounded-full border-2 ${provColor}`}></span>
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-semibold text-white">{st.stage.replace(/_/g, ' ')}</h4>
                              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${provColor}`}>
                                {st.link_provenance}
                              </span>
                            </div>
                            <p className="text-xs font-mono text-slate-400 mt-0.5">Event Ref: {st.event_ref}</p>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Traceable Evidence Citations (U5) */}
                  <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Traceable Evidence Citations (U5)
                      </h3>
                      <span className="text-xs font-mono text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded bg-emerald-950">
                        100% Validated in Raw
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {selectedAlert.evidence_refs.map((ref, idx) => (
                        <div key={idx} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono">
                          <div className="text-indigo-400 font-semibold truncate">{ref.source_file}</div>
                          <div className="text-slate-400 text-[11px] mt-1">Line / Record: {ref.record_id}</div>
                          <div className="text-emerald-400 text-[10px] mt-2 flex items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5"></span>
                            RESOLVED IN RAW
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Simulated Response Panel (M4) */}
                  <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                          Simulated Response & Mitigation Gate (M4)
                        </h3>
                        <p className="text-xs text-slate-500">Tier-based recommended policy action</p>
                      </div>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                        Action: {selectedAlert.recommended_action}
                      </span>
                    </div>

                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                      <div>
                        <span className="text-slate-400 font-medium">Target Identity: </span>
                        <span className="font-mono text-slate-200">{formatIdentity(selectedAlert.subject.id)}</span>
                      </div>
                      <div className="text-slate-500 font-mono text-[11px]">
                        Requires Analyst Sign-Off
                      </div>
                    </div>

                    <div className="flex items-center justify-end space-x-3 pt-2">
                      <button
                        onClick={handleStepUp}
                        className="px-4 py-2 rounded-lg text-xs font-medium border border-indigo-700 bg-indigo-950 hover:bg-indigo-900 text-indigo-300 transition-colors cursor-pointer"
                      >
                        Simulate Step-Up MFA Challenge
                      </button>

                      {simResult ? (
                        <span className="px-4 py-2 rounded-lg text-xs font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-2"></span>
                          Result: {simResult} (SIMULATED)
                        </span>
                      ) : (
                        <button
                          onClick={handleApprove}
                          className="px-5 py-2 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
                        >
                          Authorize & Dispatch Simulated {selectedAlert.recommended_action}
                        </button>
                      )}
                    </div>

                    {stepUpPrompt && (
                      <div className="p-3 rounded-lg border border-indigo-800 bg-indigo-950/40 text-xs text-indigo-300 font-mono">
                        {stepUpPrompt}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="p-12 text-center border border-slate-800 rounded-xl bg-slate-900/20 text-slate-500 text-xs">
                  Select an incident from the queue to view details.
                </div>
              )}
            </section>
          </div>
        )}

        {/* Tab 2: Attack Graph & Privilege Paths (B8 Stretch) */}
        {activeTab === 'graph' && graphData && (
          <div className="space-y-6">
            <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white">Identity Privilege Attack Graph</h2>
                  <p className="text-xs text-slate-400">Mapped relationships across identities, assumed roles, policies, and target resources</p>
                </div>
                <span className="text-xs font-mono text-indigo-400 border border-indigo-800 bg-indigo-950 px-2.5 py-0.5 rounded-full">
                  {graphData.nodes.length} Nodes • {graphData.edges.length} Edges
                </span>
              </div>

              {/* Inline SVG Attack Graph */}
              <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-6 overflow-x-auto">
                <svg viewBox="0 0 800 240" className="w-full h-60 min-w-[700px]">
                  <defs>
                    <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                      <path d="M 0 0 L 10 5 L 0 10 z" fill="#6366f1" />
                    </marker>
                  </defs>

                  {/* Nodes */}
                  <g transform="translate(60, 100)">
                    <rect width="130" height="50" rx="8" fill="#1e1b4b" stroke="#6366f1" strokeWidth="2" />
                    <text x="65" y="25" fill="#e0e7ff" fontSize="11" textAnchor="middle" fontWeight="bold">Dormant Contractor</text>
                    <text x="65" y="40" fill="#a5b4fc" fontSize="9" textAnchor="middle" fontFamily="monospace">bob.contractor</text>
                  </g>

                  <line x1="190" y1="125" x2="270" y2="125" stroke="#6366f1" strokeWidth="2" markerEnd="url(#arrow)" />
                  <text x="230" y="115" fill="#818cf8" fontSize="9" textAnchor="middle" fontFamily="monospace">AssumeRole</text>

                  <g transform="translate(270, 100)">
                    <rect width="120" height="50" rx="8" fill="#1e293b" stroke="#94a3b8" strokeWidth="2" />
                    <text x="60" y="25" fill="#f8fafc" fontSize="11" textAnchor="middle" fontWeight="bold">Cloud Role</text>
                    <text x="60" y="40" fill="#94a3b8" fontSize="9" textAnchor="middle" fontFamily="monospace">DataAnalystRole</text>
                  </g>

                  <line x1="390" y1="125" x2="470" y2="125" stroke="#ef4444" strokeWidth="2" strokeDasharray="4 2" markerEnd="url(#arrow)" />
                  <text x="430" y="115" fill="#f87171" fontSize="9" textAnchor="middle" fontFamily="monospace">AttachPolicy</text>

                  <g transform="translate(470, 100)">
                    <rect width="130" height="50" rx="8" fill="#450a0a" stroke="#ef4444" strokeWidth="2" />
                    <text x="65" y="25" fill="#fecaca" fontSize="11" textAnchor="middle" fontWeight="bold">Escalated Policy</text>
                    <text x="65" y="40" fill="#fca5a5" fontSize="9" textAnchor="middle" fontFamily="monospace">AdminAccess</text>
                  </g>

                  <line x1="600" y1="125" x2="670" y2="125" stroke="#ef4444" strokeWidth="2" markerEnd="url(#arrow)" />
                  <text x="635" y="115" fill="#f87171" fontSize="9" textAnchor="middle" fontFamily="monospace">Access</text>

                  <g transform="translate(670, 100)">
                    <rect width="110" height="50" rx="8" fill="#7f1d1d" stroke="#f87171" strokeWidth="2" />
                    <text x="55" y="25" fill="#ffffff" fontSize="11" textAnchor="middle" fontWeight="bold">Target Vault</text>
                    <text x="55" y="40" fill="#fca5a5" fontSize="9" textAnchor="middle" fontFamily="monospace">pii-vault</text>
                  </g>
                </svg>
              </div>

              {/* Ranked Critical Paths */}
              <div className="space-y-3 pt-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Ranked Critical Privilege Paths</h3>
                {graphData.ranked_paths.map((p, idx) => (
                  <div key={idx} className="p-4 border border-rose-900/60 bg-rose-950/20 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-rose-900 text-rose-200 border border-rose-700">
                        {p.risk_level} PATH
                      </span>
                      <span className="text-xs font-mono text-slate-400">{p.path_id}</span>
                    </div>
                    <p className="text-xs text-slate-300 font-medium">{p.description}</p>
                    <div className="flex items-center space-x-2 text-xs font-mono pt-1 text-slate-400 overflow-x-auto">
                      {p.hops.map((h, i) => (
                        <span key={i} className="flex items-center space-x-1.5 shrink-0">
                          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">{h.node}</span>
                          {i < p.hops.length - 1 && <span className="text-rose-400 font-bold">→</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Model Tuning & Feedback Loop (B8 Stretch) */}
        {activeTab === 'feedback' && (
          <div className="space-y-6">
            <div className="p-6 border border-slate-800 rounded-xl bg-slate-900/40 backdrop-blur space-y-4">
              <div>
                <h2 className="text-base font-bold text-white">Analyst Feedback Adaptation Engine</h2>
                <p className="text-xs text-slate-400">
                  Bounded dynamic multiplicative weight tuning (±10%, clamped strictly between 0.5× and 2.0× baseline).
                  All adaptations are audited to the tamper-evident log and reversible.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {Object.entries(weights).map(([factor, weight]) => (
                  <div key={factor} className="p-4 border border-slate-800 bg-slate-950 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white capitalize">{factor.replace(/_/g, ' ')}</span>
                      <span className="text-xs font-mono font-bold text-indigo-400">{weight}</span>
                    </div>
                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${Math.min(100, weight * 200)}%` }}></div>
                    </div>
                    <div className="flex items-center justify-end space-x-2 pt-1">
                      <button
                        onClick={() => handleWeightFeedback(factor, 'DECREASE')}
                        className="px-2.5 py-1 text-xs rounded bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 font-mono cursor-pointer"
                      >
                        -10%
                      </button>
                      <button
                        onClick={() => handleWeightFeedback(factor, 'INCREASE')}
                        className="px-2.5 py-1 text-xs rounded bg-indigo-950 border border-indigo-700 hover:border-indigo-500 text-indigo-300 font-mono cursor-pointer"
                      >
                        +10%
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="border-t border-slate-900 py-3 text-center text-xs text-slate-600 font-mono">
        Zero Trust Identity Protection Engine • Track 2 • Full Stack Build
      </footer>
    </div>
  )
}
