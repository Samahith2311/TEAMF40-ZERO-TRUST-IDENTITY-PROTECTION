from typing import Dict, Any, List
from src.scoring import FACTOR_WEIGHTS

# Dynamic weight state initialized from baseline
_dynamic_weights = dict(FACTOR_WEIGHTS)
_history: List[Dict[str, Any]] = []

def get_current_weights() -> Dict[str, float]:
    return dict(_dynamic_weights)

def apply_analyst_feedback(factor: str, direction: str, analyst: str = "analyst@corp.internal") -> Dict[str, Any]:
    """
    Applies bounded multiplicative weight update (+/-10%).
    Clamped strictly between 0.5x and 2.0x of baseline weight.
    Reversible via rollback.
    """
    if factor not in FACTOR_WEIGHTS:
        raise ValueError(f"Unknown factor: {factor}")
    if direction not in ["INCREASE", "DECREASE"]:
        raise ValueError(f"Direction must be INCREASE or DECREASE, got: {direction}")

    base_w = FACTOR_WEIGHTS[factor]
    min_w = base_w * 0.5
    max_w = base_w * 2.0
    curr_w = _dynamic_weights[factor]

    # Save snapshot for revertibility
    _history.append({
        "weights": dict(_dynamic_weights),
        "factor": factor,
        "direction": direction,
        "analyst": analyst
    })

    multiplier = 1.10 if direction == "INCREASE" else 0.90
    new_w = curr_w * multiplier

    # Strict clamping bounds
    clamped_w = max(min_w, min(max_w, new_w))
    _dynamic_weights[factor] = round(clamped_w, 4)

    return {
        "factor": factor,
        "previous_weight": curr_w,
        "new_weight": _dynamic_weights[factor],
        "baseline_weight": base_w,
        "bounds": {"min": round(min_w, 4), "max": round(max_w, 4)},
        "analyst": analyst
    }

def revert_last_feedback() -> Dict[str, Any]:
    global _dynamic_weights
    if not _history:
        return {"status": "NO_HISTORY", "weights": dict(_dynamic_weights)}
    last = _history.pop()
    _dynamic_weights = dict(last["weights"])
    return {"status": "REVERTED", "weights": dict(_dynamic_weights)}

