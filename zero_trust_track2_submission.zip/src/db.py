import logging
from pymongo import MongoClient, ASCENDING
from src.config import MONGODB_URI, COLLECTIONS

logger = logging.getLogger(__name__)

_client = None

def get_client(uri: str = None) -> MongoClient:
    global _client
    if _client is None:
        target_uri = uri or MONGODB_URI
        _client = MongoClient(target_uri, serverSelectionTimeoutMS=3000)
    return _client

def get_db(client: MongoClient = None):
    c = client or get_client()
    # If URI contains DB name, use default database, else fallback to zero_trust_db
    try:
        db = c.get_default_database()
        if db is not None:
            return db
    except Exception:
        pass
    return c["zero_trust_db"]

def setup_db(db=None):
    """
    Sets up required collections, indexes, and $jsonSchema validation rules.
    """
    if db is None:
        db = get_db()

    # Define JSON Schema for normalized_events
    schema = {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["event_id", "source", "source_file", "ts_utc", "identity_key", "action", "raw_hash"],
            "properties": {
                "event_id": {"bsonType": "string"},
                "source": {"enum": ["okta", "cloudtrail", "synthetic"]},
                "source_file": {"bsonType": "string"},
                "record_ref": {"bsonType": ["string", "int", "long"]},
                "ts_utc": {"bsonType": "string"},
                "ts_original_tz": {"bsonType": ["string", "null"]},
                "identity_key": {"bsonType": "string"},
                "principal_raw": {"bsonType": "string"},
                "session_id": {"bsonType": ["string", "null"]},
                "ip": {"bsonType": "string"},
                "geo": {"bsonType": "object"},
                "user_agent": {"bsonType": "string"},
                "action": {"bsonType": "string"},
                "resource": {"bsonType": "string"},
                "outcome": {"bsonType": "string"},
                "privilege_context": {"bsonType": "object"},
                "raw_hash": {"bsonType": "string"},
                "validation": {
                    "bsonType": "object",
                    "required": ["status"],
                    "properties": {
                        "status": {"enum": ["VALID", "INVALID", "QUARANTINED"]},
                        "reasons": {"bsonType": "array", "items": {"bsonType": "string"}}
                    }
                }
            }
        }
    }

    # Create collection with validator or update validator
    existing_cols = db.list_collection_names()
    if COLLECTIONS["normalized_events"] not in existing_cols:
        db.create_collection(COLLECTIONS["normalized_events"], validator=schema)
    else:
        try:
            db.command("collMod", COLLECTIONS["normalized_events"], validator=schema)
        except Exception as e:
            logger.warning(f"Could not update validator on normalized_events: {e}")

    # Unique index on (source, event_id) to guarantee idempotency
    db[COLLECTIONS["normalized_events"]].create_index(
        [("source", ASCENDING), ("event_id", ASCENDING)],
        unique=True,
        name="idx_source_event_id_unique"
    )

    # Index on identity_key and ts_utc for fast correlation
    db[COLLECTIONS["normalized_events"]].create_index(
        [("identity_key", ASCENDING), ("ts_utc", ASCENDING)],
        name="idx_identity_ts"
    )

    # Unique index on dedupe key for alerts
    db[COLLECTIONS["alerts"]].create_index(
        [("alert_id", ASCENDING)],
        unique=True,
        name="idx_alert_id_unique"
    )
    db[COLLECTIONS["alerts"]].create_index(
        [("incident_id", ASCENDING)],
        name="idx_alert_incident_id"
    )

    # Unique index on incident_id for incident chains
    db[COLLECTIONS["incident_chains"]].create_index(
        [("incident_id", ASCENDING)],
        unique=True,
        name="idx_incident_chain_unique"
    )

    return db
