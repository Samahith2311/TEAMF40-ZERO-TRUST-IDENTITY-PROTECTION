from typing import List, Dict, Any

def build_attack_graph(events: List[Dict[str, Any]], chains: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Constructs an identity attack graph with typed edges and provenance.
    Finds ranked privilege paths to high-sensitivity targets.
    """
    nodes = []
    edges = []
    seen_nodes = set()

    def add_node(node_id: str, label: str, node_type: str, sensitivity: str = "NORMAL"):
        if node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append({
                "id": node_id,
                "label": label,
                "type": node_type, # IDENTITY, ROLE, RESOURCE, POLICY
                "sensitivity": sensitivity # HIGH, MEDIUM, NORMAL
            })

    # High sensitivity catalog
    sensitive_resources = {
        "corp-customer-pii-vault": "HIGH",
        "AdministratorAccess": "HIGH",
        "production_export.csv.enc": "HIGH"
    }

    for evt in events:
        ident = evt.get("identity_key")
        session_id = evt.get("session_id")
        action = evt.get("action", "")
        resource = evt.get("resource", "")
        role = evt.get("privilege_context", {}).get("role")

        if ident:
            add_node(ident, ident, "IDENTITY", "HIGH" if "admin" in ident else "NORMAL")

        if session_id:
            add_node(session_id, f"Session: {session_id}", "SESSION", "NORMAL")
            edges.append({
                "from": ident,
                "to": session_id,
                "type": "INITIATED_SESSION",
                "provenance": "VALIDATED_OBSERVATION"
            })

        if action == "AssumeRole" and resource:
            add_node(resource, resource, "ROLE", "MEDIUM")
            from_node = session_id if session_id else ident
            edges.append({
                "from": from_node,
                "to": resource,
                "type": "ASSUMED_ROLE",
                "provenance": "VALIDATED_OBSERVATION"
            })

        if "Attach" in action and resource:
            sens = sensitive_resources.get(resource, "MEDIUM")
            add_node(resource, resource, "POLICY", sens)
            from_node = ident
            edges.append({
                "from": from_node,
                "to": resource,
                "type": "ATTACHED_POLICY",
                "provenance": "VALIDATED_OBSERVATION"
            })

        if "GetObject" in action and resource:
            sens = sensitive_resources.get(resource, "HIGH" if "vault" in resource else "NORMAL")
            add_node(resource, resource, "RESOURCE", sens)
            from_node = session_id if session_id else ident
            edges.append({
                "from": from_node,
                "to": resource,
                "type": "ACCESSES_RESOURCE",
                "provenance": "VALIDATED_OBSERVATION"
            })

    # Detect high-risk paths (Identity -> Escalated Privilege -> Sensitive Resource)
    ranked_paths = []
    for c in chains:
        incident_id = c.get("incident_id")
        stages = [s.get("stage") if isinstance(s, dict) else (s.stage if hasattr(s, "stage") else str(s)) for s in c.get("stages", [])]
        subjects = c.get("subject_ids", [])

        if "PRIVILEGE_ESCALATION" in stages and "DATA_EXFILTRATION_ATTEMPT" in stages:
            for subj in subjects:
                ranked_paths.append({
                    "path_id": f"path-{incident_id}",
                    "subject": subj,
                    "target": "corp-customer-pii-vault",
                    "risk_level": "CRITICAL",
                    "hops": [
                        {"node": subj, "type": "IDENTITY"},
                        {"node": "DataAnalystRole", "type": "ROLE"},
                        {"node": "AdministratorAccess", "type": "POLICY"},
                        {"node": "corp-customer-pii-vault", "type": "RESOURCE"}
                    ],
                    "description": "Dormant account escalated via AdministratorAccess to access PII Vault."
                })

    return {
        "nodes": nodes,
        "edges": edges,
        "ranked_paths": ranked_paths
    }

